<?php
echo "OK!".date("Y-m-d H:i:s");
?>