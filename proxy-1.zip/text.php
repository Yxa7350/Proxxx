<?php
if(isset($_POST["content"])){
  file_put_contents("text.txt",$_POST["content"]);
}
?>
<html>
  <body>
    <form action="text.php" method="POST">
      <textarea name="content"><?php echo file_get_contents("text.txt"); ?></textarea>
      <input type="submit" value="Submit text">
    </form>
      </body>
</html>