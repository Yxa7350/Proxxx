# PHP Web Server

This is the Template Repl for PHP Web Server.

PHP is a popular general-purpose scripting language that makes it very easy to create servers.

[Check out the official docs here](https://www.php.net/docs.php).