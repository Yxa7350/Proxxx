<?php
/*
Simproxy v1.0 函数文件
*/

//查找两字符串中间的字符，返回一个数组
function findParagraphs($content,$a,$b){
  $result=array();
  $c=explode($a,$content);
  $id=0;
  if(count($c)>1){
    foreach($c as $d => $e){
      if(strpos($e,$b)!==false&&$d!=0){
        $result[$id]=explode($b,$e,2)[0];
        $id++;
      }
    }
  }
  return $result;
}
//URL 操作
class URL{
  function isAvailable($url){
    if(preg_match("/http[s]?:\/\/[\w.]+[\w\/]*[\w.]*\??[\w=&\+\%]*/is",$url)){
      return true;
    }
    return false;
  }
  function getProxyURL(){
    if($this->isProxyPage()){
      $a=explode("/view/",$_SERVER["REQUEST_URI"])[1];
      $main=$a;
      $args="";
      if(strpos($a,"?")!==false){
        $main=explode("?",$a,2)[0];
        $args=explode("?",$a,2)[1];
      }
      return base64_decode($main)."?".$args;
    }
    return false;
  }
  //将相对路径替换成绝对路径，并进行base64编码
  function replace($url){
    if($this->isProxyPage()){
      if(substr($url,0,5)=="data:"){
        return $url;
      }
      if(strpos($url,"?")!==false)
         {
         $main=explode("?",$url,2)[0];
      $args=explode("?",$url,2)[1];
    }else{
           $main=$url;
           $args="";
    }
      if(substr($url,0,1)=="/"){
        if(count(explode("/",$this->getProxyURL()))>4){
          $root=explode(parse_url($this->getProxyURL(),PHP_URL_PATH),$this->getProxyURL(),2)[0];
        }else{
          $host=parse_url($this->getProxyURL(),PHP_URL_HOST);
          $port=parse_url($this->getProxyURL(),PHP_URL_PORT);
          if(is_null($port)){
            $root=parse_url($this->getProxyURL(),PHP_URL_SCHEME)."://".$host;
          }else{
            $root=parse_url($this->getProxyURL(),PHP_URL_SCHEME)."://".$host.":".$port;
          }
          
        }
        return base64_encode($root.$main)."?".$args;
      }else if(substr($url,0,1)=="?"){
        return $url;
      }else if(strpos($url,"http://")===false&&strpos($url,"https://")===false){
        $parent=explode(end(explode("/",$this->getProxyURL())),$this->getProxyURL(),2)[0];
        return base64_encode($parent.$main)."?".$args;
      }else{
        return base64_encode($main)."?".$args;
      }
    }
  }
  function isProxyPage(){
    if(strpos($_SERVER["REQUEST_URI"],"/view/")!==false&&explode("/view/",$_SERVER["REQUEST_URI"])[1]!=""){
      return true;
    }else{
      return false;
    }
  }
}
$Url=new URL();
//使用 file_get_contents 函数进行 http 请求
class FgcHttp{
  function __construct($url){
    $Url=new URL();
    $this->url=$url;
    $this->isPost=0;
    $this->userAgent=$_SERVER["HTTP_USER_AGENT"];
    $this->postData=null;
    $this->result=null;
    $this->isSucceed=false;
    $this->errorMessage=null;
  }
  function send(){
    ini_set("user_agent",$this->userAgent);
    if($this->isPost=1&&$this->postData){
      $a["http"]=array(
        'timeout'=>60,
        'method'=>"POST",
      'header'=>"Content-Type: application/x-www-form-urlencoded;charset=utf-8",
        'content'=>http_build_query($this->postData)
        );
      $context=stream_context_create($a);
      $result=@file_get_contents($this->url,false,$context);
    }else{
        $result=@file_get_contents($this->url);
    }
    if($result){
      $this->result=$result;
      $this->isSucceed=true;
    }else{
      $this->errorMessage=error_get_last()["message"];
    }
  }
}
//使用 CURL 进行 http 请求
class CurlHttp{
  function __construct($url){
    $Url=new URL();
    $ch=curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_HEADER,0);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
    $this->isPost=0;
    $this->userAgent=$_SERVER["HTTP_USER_AGENT"];
    $this->postData=null;
    $this->result=null;
    $this->isSucceed=false;
    $this->errorMessage=null;
    $this->curlInfo=null;
  }
  function send(){
    curl_setopt($ch,CURLOPT_POST,$this->isPost);
    if($this->postData){
      curl_set_opt($ch,CURLOPT_POSTFIELDS,$this->postData);
    }
    curl_set_opt($ch,CURLOPT_USERAGENT,$this->userAgent);
    $result=curl_exec($ch);
    $this->curlInfo=curl_getinfo($ch);
    if(curl_error($ch)){
      $this->errorMessage=curl_error($ch);
    }else{
      $this->isSucceed=true;
      $this->result=$result;
    }
    curl_close();
  }
}
?>