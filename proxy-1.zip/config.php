<?php
/*
Simproxy v1.0 配置文件
*/

//代理根目录
define("PROXY_ROOT","");
//页面主题
define("PROXY_THEME","default");
//代理 UA 设置，设为空表示使用用户 UA
define("PROXY_UA","");
//访问密码，设为空表示不使用密码
define("PROXY_PASSWORD","");
//是否禁用被代理页面的 JavaScript
define("PROXY_NOSCRIPT",false);
?>