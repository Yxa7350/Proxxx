<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1">
    <title>出错啦</title>
  </head>
  <body>
    <h1>无法请求网页</h1>
    <div>错误信息：<?php echo $errorMessage; ?></div>
  </body>
</html>