<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1">
    <title>身份验证</title>
  </head>
  <body>
    <form action="" method="post">
      <div>您需要输入正确的密码才能继续使用：</div>
      <?php if($password_error==true){echo "<div>密码错误!</div>";} ?>
      <input type="text" value="" name="pwd">
      <div><input type="submit" value="提交"></div>
    </form>
  </body>
</html>