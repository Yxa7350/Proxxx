<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=1">
    <title>Simproxy</title>
    <link rel="stylesheet" href="<?php echo PROXY_ROOT; ?>/theme/<?php echo PROXY_THEME; ?>/style.css">
  </head>
  <body>
    <h1>Simproxy</h1>
    <form method="POST" action="">
      <input type="text" name="url" placeholder="输入 URL..."><input type="submit" value="立即访问">
    </form>
    <div id="site-list">
      <a href="<?php echo PROXY_ROOT; ?>/view/aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8="><img src="<?php echo PROXY_ROOT; ?>/theme/<?php echo PROXY_THEME; ?>/icon/google.png"><span>Google</span></a>
      <a href="<?php echo PROXY_ROOT; ?>/view/aHR0cHM6Ly93d3cuZHVja2R1Y2tnby5jb20v"><img src="<?php echo PROXY_ROOT; ?>/theme/<?php echo PROXY_THEME; ?>/icon/duckduckgo.png"><span>DuckDuckGo</span></a>
    </div>
    <center>Simproxy v<?php echo PROXY_VERSION; ?></center>
  </body>
</html>