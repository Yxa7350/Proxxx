<?php
define("PROXY_VERSION","1.0");
require("config.php");
require("functions.php");
if(!$Url->isProxyPage()){
  if(empty($_POST["url"])){
    require("theme/".PROXY_THEME."/home.php");
  }else{
    $url=$_POST["url"];
    $main=$url;
    $args="";
    if(strpos($url,"?")!==false){
      $main=explode("?",$url,2)[0];
      $args=explode("?",$url,2)[1];
    }
    $url=base64_encode($main)."?".$args;
    header("Location: ".PROXY_ROOT."/view/".$url);
  }
}else{
  if(PROXY_PASSWORD!=""&&!isset($COOKIE["token"])&&$_COOKIE["token"]!=md5(PROXY_PASSWORD)){
    $pwd=$_POST["pwd"];
    if(isset($pwd)&&$pwd==PROXY_PASSWORD){
      setcookie("token",md5(PROXY_PASSWORD),time()+60*60*24*30);
      header("Refresh:0");
    }else{
      if(isset($pwd)&&$pwd!=PROXY_PASSWORD){
        $password_error=true;
      }require("theme/".PROXY_THEME."/password.php");
    }
  }else{
    if(function_exists("curl_init")){
      $r=new CurlHttp($Url->getProxyURL());
    }else{
      $r=new FgcHttp($Url->getProxyURL());
    }
    if(PROXY_UA!=""){
      $r->userAgent=PROXY_UA;
    }
    if(count($_POST)>0){
      $r->isPost=1;
      $r->postData=$_POST;
    }
    $r->send();
    if(!$r->isSucceed){
      $errorMessage=$r->errorMessage;
      require("theme/".PROXY_THEME."/error.php");
    }else{
      $html=$r->result;
      $href_links=findParagraphs($html,'href="','"');
      $src_links=findParagraphs($html,'src="','"');
      $action_links=findParagraphs($html,' action="','"');
      if(!empty($href_links)){
        foreach($href_links as $item){
          $html=str_replace('href="'.$item.'"','href="'.$Url->replace($item).'"',$html);
        }
      }
      if(!empty($src_links)){
        foreach($src_links as $item){
          $html=str_replace('src="'.$item.'"','src="'.$Url->replace($item).'"',$html);
        }
      }
      if(!empty($action_links)){
        foreach($action_links as $item){
          $html=str_replace(' action="'.$item.'"',' action="'.$Url->replace($item).'"',$html);
        }
      }
      echo $html;
    }
  }
}
?>